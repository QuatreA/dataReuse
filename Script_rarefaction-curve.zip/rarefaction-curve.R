
####
# Author : Mélissa Hanafi-Portier #
####

#### Load package ####
library(tidyverse)
library(vegan)
library(erer)
library(iNEXT)

#### Read file ####

## Tas Seamounts
ImageAnnotations <- read_csv(file = "FILE/ImageAnnotations.csv")
PC_cover <- read_csv(file = "FILE/PC_cover.csv")
QuadImg <- read_csv(file = "FILE/QuadImg.csv", col_types = cols(.default = col_character(),
                                                                Pts_p_Img = col_double(),
                                                                Quad_size = col_double(),
                                                                DEPTH_METERS = col_double(),
                                                                LONGITUDE = col_double(),
                                                                LATITUDE = col_double(),
                                                                SM_Ops = col_factor(),
                                                                image_key = col_factor()))

## Dive05 Mayotte
image_may <- read_csv(file = "FILE/2_dive05_biomaglo_taxo_abund.csv") %>%
  mutate(mean_image_area = "8.51") %>%
  relocate(mean_image_area, .after = "filename") %>%
  select(!c(X4, Actiniaria_inc, Enallopsammia_inc)) 



#### Tas SM : Dataset preparation ####
#### --> Transform density data into MATRIX (wide) format and add geolocation ####

# selecting the x,y,z position data and Quadrat-size from QuadImg.csv
geoloc <- QuadImg %>% 
  select(image_key, LATITUDE, LONGITUDE, DEPTH_METERS, Quad_size, SM_Ops)


# Density data at PT_comm Id level matrix excluding identifications at too high level and p/a only data, converting long format to wide format; introducing 0 for NA, removing the zero VME fauna placeholder and adding the geolocation data

# --> at PT_comm ID level
# PT_DensMATRIX <- ImageAnnotations %>% 
#   filter(ID_lev !='ex'&
#            !is.na(Dens)) %>%
#   group_by(image_key, PT_Comm) %>% 
#   summarise(PTdens = sum(Dens)) %>% # sum the densities for each taxa of PT_comm for each image
#   ungroup() %>% #  WARNING: ungroup() before !
#   spread(key = PT_Comm, value = PTdens) %>% # spread with Pt_comm taxa in column, containing the summed density values in the cells
#   mutate(across(everything(), ~replace_na(.x, 0))) %>% # for each column, replace NA with 0
#   select(-'No-VMEfauna') %>% # remove the column "No. VME"
#   inner_join(geoloc, by = c("image_key"="image_key")) # join the xy data, according to "image_key".
# ## `summarise()` has grouped output by 'image_key'. You can override using the `.groups` argument.


# # --> at CATAMI ID level
# CAT_MATRIX <- ImageAnnotations %>% 
#   filter(ID_lev !='ex'&
#            !is.na(Dens)) %>%
#   group_by(image_key, CATAMI) %>% 
#   summarise(CATdens = sum(Dens)) %>% 
#   ungroup() %>%
#   spread(key = CATAMI, value = CATdens) %>% 
#   mutate(across(everything(), ~replace_na(.x, 0))) %>% 
#   select(-'No-VMEfauna') %>%
#   inner_join(geoloc, by = c("image_key"="image_key")) 
# ## `summarise()` has grouped output by 'image_key'. You can override using the `.groups` argument.



#  Occurrence data matrix, excluding identifications at too high level, but including the p/a only data, by creating a pres field; converting long format to wide format, introducing 0 for NA, removing the zero VME fauna placeholder and adding the geolocation data.

PT_paMATRIX <- ImageAnnotations %>%
  filter(ID_lev !='ex') %>%
  group_by(image_key, PT_Comm) %>%
  summarise(pres = n()) %>%
  ungroup() %>%
  mutate(pres = 1) %>%
  spread(key = PT_Comm, value = pres) %>%
  mutate(across(everything(), ~replace_na(.x, 0))) %>%
  select(-'No-VMEfauna') %>%
  inner_join(geoloc, by = c("image_key"="image_key"))
## `summarise()` has grouped output by 'image_key'. You can override using the `.groups` argument.


#### Rarefaction curves ####
## sub-samples of sites by mount ##

# Hill U
Hill_U <- PT_paMATRIX  %>%
  filter(SM_Ops %in% "Hill U") %>%
  select(-LATITUDE, 
         -LONGITUDE, 
         -DEPTH_METERS,
         -Quad_size,
         -SM_Ops) %>%
  column_to_rownames(var = "image_key") 

# Hill_U_info <- PT_paMATRIX  %>%
#   filter(SM_Ops %in% "Hill U") %>%
#   select(-LATITUDE,
#          -LONGITUDE,
#          -DEPTH_METERS,
#          -SM_Ops) %>%
#   mutate(total_quad_size = sum(Quad_size))
# 
# summary(Hill_U_info$Quad_size)

# Dive05 Mayotte
May <- image_may  %>%
  select(-dive, 
         -mean_image_area,
         -campagne) %>%
  column_to_rownames(var = "filename") 


## convert into P/A data ##
Hill_U <- decostand(Hill_U, method = "pa")
May <- decostand(May, method = "pa")


## transpose the matrix to obtain a species by site matrix ##
Hill_U <- t(Hill_U)
May <- t(May)


## calculate the frequency (no. of sampling units in which taxa "X" is found => its frequency of occurrence##
## the first row of the matrix will correspond to the number of samples in the considered dive ##
Hill_U_incfreq <- as.matrix(as.incfreq(Hill_U))
May_incfreq <- as.matrix(as.incfreq(May))

## create the list of dives (or transects) for the iNEXT calculation ##
list<- list(Hill_U_incfreq, May_incfreq)
names(list) <- c("Hill_U", "Mayotte")

## create an object containing the list of colours per dive to be implemented in the ggplot  ##
color_dive <- c('#1b9e77','#d95f02')


## calculation of the rarefaction curve ##
# Hill U = 305 sampling units (quadrats), Dive05 Mayotte = 899 sampling units (images)
inext_pa <-iNEXT(list, q = 0, datatype = "incidence_freq", endpoint = 1800, nboot = 999) #endpoint = 1800 sampling units corresponding to twice the size of the referecnce sample size (899 images); hill number q = 0 (richness), q = 1 (Shannon), q = 2 (Simpson)


## representation of the curve with ggplot ##
gg_raref <- ggiNEXT(inext_pa, type = 1, color.var = "Assemblage", se = T, facet.var = "None") + 
  scale_color_manual(values = color_dive,
                     labels = c("Hill U", "MayDeepSlope")) +
  scale_fill_manual(values = color_dive,
                    labels = c("Hill U", "MayDeepSlope"))  +
  scale_shape_manual(values = c(19, 19))+
  #theme(legend.position = "right") +
  labs(y = "Taxonomic richness", x = "Number of sampling units") +
  theme_grey() + 
  guides(shape = "none", 
         color = guide_legend("Seamounts"),
         fill = guide_legend("Seamounts")) +
  theme(axis.title.x = element_text(size=13), # change the size of the x-axis title
        axis.text.x = element_text(size = 11), # change the size of the x-labels
        axis.title.y = element_text(size = 13), # change the size of the ordinate title
        axis.text.y = element_text(size = 10),
        legend.text = element_text(size = 12), # change the size of the caption labels
        legend.title = element_text(size = 14)) # change the size of the caption titles
gg_raref

## Save the plot ##
ggsave(filename = "EXPORT/raref_sample-based-PTpaMATRIX.png", plot = gg_raref, width = 11, height = 8, dpi = 300)



## export values ##
Data_infos <- inext_pa$DataInfo 
Estimates_asymptotes  <- inext_pa$AsyEst
Estimates <- inext_pa$iNextEst
Estimates_for_1800_sample_size <- estimateD(list, datatype = "incidence_freq", base = "size", level = 1800)  # compute the diversity for 1800 sampling units 
Estimates_for_305_sample_size <- estimateD(list, datatype = "incidence_freq", base = "size", level = 305)  # compute the diversity for the minimum sample size among all sites

outputs <- list(Data_infos, Estimates_asymptotes, Estimates,  Estimates_for_1800_sample_size, Estimates_for_305_sample_size)
names(outputs) <- c("Data_infos", "Estimates_asymptotes", "Estimates", "Estimates_extrapolation_1800", "Estimates_interpolation_305")
write.list(outputs, file = "EXPORT/export_richness_comparaison_iNEXT-PTpaMATRIX.csv" )


